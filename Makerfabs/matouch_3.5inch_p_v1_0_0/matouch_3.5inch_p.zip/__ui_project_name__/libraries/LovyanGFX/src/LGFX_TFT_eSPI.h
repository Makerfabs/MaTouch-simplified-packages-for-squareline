#pragma once

#ifdef __cplusplus

#include "LGFX_TFT_eSPI.hpp"

#else

#error LovyanGFX requires a C++ compiler, please change file extension to .cc or .cpp

#endif
